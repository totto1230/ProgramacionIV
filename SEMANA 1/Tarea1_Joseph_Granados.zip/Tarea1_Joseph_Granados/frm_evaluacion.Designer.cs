﻿namespace Tarea1_Joseph_Granados
{
    partial class frm_evaluacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.b_cerrar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tx_nota_final = new System.Windows.Forms.TextBox();
            this.b_nota = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tx_parcial1 = new System.Windows.Forms.TextBox();
            this.tx_parcial2 = new System.Windows.Forms.TextBox();
            this.tx_parcial3 = new System.Windows.Forms.TextBox();
            this.tx_nota_tareas = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tx_4 = new System.Windows.Forms.Label();
            this.tx_tarea1 = new System.Windows.Forms.TextBox();
            this.tx_tarea2 = new System.Windows.Forms.TextBox();
            this.tx_tarea3 = new System.Windows.Forms.TextBox();
            this.tx_tarea4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tx_quiz1 = new System.Windows.Forms.TextBox();
            this.tx_quiz2 = new System.Windows.Forms.TextBox();
            this.tx_quiz3 = new System.Windows.Forms.TextBox();
            this.tx_quiz_total = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tx_porc_quizzes = new System.Windows.Forms.TextBox();
            this.tx_porc_tareas = new System.Windows.Forms.TextBox();
            this.tx_porc_parcial1 = new System.Windows.Forms.TextBox();
            this.tx_porc_parcial2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tx_porc_parcial3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.tx_porc_parcial3);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.tx_porc_parcial2);
            this.groupBox1.Controls.Add(this.tx_porc_parcial1);
            this.groupBox1.Controls.Add(this.tx_porc_tareas);
            this.groupBox1.Controls.Add(this.tx_porc_quizzes);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(453, 110);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Porcentajes de Evaluación";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tx_quiz_total);
            this.groupBox2.Controls.Add(this.tx_quiz3);
            this.groupBox2.Controls.Add(this.tx_quiz2);
            this.groupBox2.Controls.Add(this.tx_quiz1);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox2.Location = new System.Drawing.Point(12, 128);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(453, 67);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Notas Quices";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tx_tarea4);
            this.groupBox3.Controls.Add(this.tx_tarea3);
            this.groupBox3.Controls.Add(this.tx_tarea2);
            this.groupBox3.Controls.Add(this.tx_tarea1);
            this.groupBox3.Controls.Add(this.tx_4);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.tx_nota_tareas);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox3.Location = new System.Drawing.Point(12, 201);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(453, 73);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Notas Tareas";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tx_parcial3);
            this.groupBox4.Controls.Add(this.tx_parcial2);
            this.groupBox4.Controls.Add(this.tx_parcial1);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox4.Location = new System.Drawing.Point(12, 280);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(379, 62);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Notas Exámenes Parciales";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.b_nota);
            this.groupBox5.Controls.Add(this.tx_nota_final);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox5.Location = new System.Drawing.Point(12, 348);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(261, 65);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Resultado Final";
            // 
            // b_cerrar
            // 
            this.b_cerrar.Location = new System.Drawing.Point(390, 390);
            this.b_cerrar.Name = "b_cerrar";
            this.b_cerrar.Size = new System.Drawing.Size(75, 23);
            this.b_cerrar.TabIndex = 2;
            this.b_cerrar.Text = "Cerrar";
            this.b_cerrar.UseVisualStyleBackColor = true;
            this.b_cerrar.Click += new System.EventHandler(this.b_cerrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nota Final:";
            // 
            // tx_nota_final
            // 
            this.tx_nota_final.Location = new System.Drawing.Point(86, 25);
            this.tx_nota_final.Name = "tx_nota_final";
            this.tx_nota_final.ReadOnly = true;
            this.tx_nota_final.Size = new System.Drawing.Size(46, 20);
            this.tx_nota_final.TabIndex = 1;
            this.tx_nota_final.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b_nota
            // 
            this.b_nota.ForeColor = System.Drawing.SystemColors.ControlText;
            this.b_nota.Location = new System.Drawing.Point(158, 25);
            this.b_nota.Name = "b_nota";
            this.b_nota.Size = new System.Drawing.Size(75, 23);
            this.b_nota.TabIndex = 2;
            this.b_nota.Text = "Ver Nota";
            this.b_nota.UseVisualStyleBackColor = true;
            this.b_nota.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(6, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Parcial#1:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(128, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Parcial#2:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(258, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Parcial#3:";
            // 
            // tx_parcial1
            // 
            this.tx_parcial1.Location = new System.Drawing.Point(70, 25);
            this.tx_parcial1.Name = "tx_parcial1";
            this.tx_parcial1.Size = new System.Drawing.Size(46, 20);
            this.tx_parcial1.TabIndex = 3;
            // 
            // tx_parcial2
            // 
            this.tx_parcial2.Location = new System.Drawing.Point(192, 25);
            this.tx_parcial2.Name = "tx_parcial2";
            this.tx_parcial2.Size = new System.Drawing.Size(46, 20);
            this.tx_parcial2.TabIndex = 6;
            // 
            // tx_parcial3
            // 
            this.tx_parcial3.Location = new System.Drawing.Point(322, 25);
            this.tx_parcial3.Name = "tx_parcial3";
            this.tx_parcial3.Size = new System.Drawing.Size(46, 20);
            this.tx_parcial3.TabIndex = 7;
            // 
            // tx_nota_tareas
            // 
            this.tx_nota_tareas.Location = new System.Drawing.Point(401, 47);
            this.tx_nota_tareas.Name = "tx_nota_tareas";
            this.tx_nota_tareas.ReadOnly = true;
            this.tx_nota_tareas.Size = new System.Drawing.Size(46, 20);
            this.tx_nota_tareas.TabIndex = 3;
            this.tx_nota_tareas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label5.Location = new System.Drawing.Point(326, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Nota Tareas:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label6.Location = new System.Drawing.Point(9, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Tarea#1:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label7.Location = new System.Drawing.Point(118, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Tarea#2:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label8.Location = new System.Drawing.Point(231, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Tarea#3:";
            // 
            // tx_4
            // 
            this.tx_4.AutoSize = true;
            this.tx_4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.tx_4.Location = new System.Drawing.Point(344, 22);
            this.tx_4.Name = "tx_4";
            this.tx_4.Size = new System.Drawing.Size(51, 13);
            this.tx_4.TabIndex = 11;
            this.tx_4.Text = "Tarea#4:";
            // 
            // tx_tarea1
            // 
            this.tx_tarea1.Location = new System.Drawing.Point(62, 19);
            this.tx_tarea1.Name = "tx_tarea1";
            this.tx_tarea1.Size = new System.Drawing.Size(46, 20);
            this.tx_tarea1.TabIndex = 8;
            // 
            // tx_tarea2
            // 
            this.tx_tarea2.Location = new System.Drawing.Point(175, 19);
            this.tx_tarea2.Name = "tx_tarea2";
            this.tx_tarea2.Size = new System.Drawing.Size(46, 20);
            this.tx_tarea2.TabIndex = 12;
            // 
            // tx_tarea3
            // 
            this.tx_tarea3.Location = new System.Drawing.Point(288, 19);
            this.tx_tarea3.Name = "tx_tarea3";
            this.tx_tarea3.Size = new System.Drawing.Size(46, 20);
            this.tx_tarea3.TabIndex = 13;
            // 
            // tx_tarea4
            // 
            this.tx_tarea4.Location = new System.Drawing.Point(401, 19);
            this.tx_tarea4.Name = "tx_tarea4";
            this.tx_tarea4.Size = new System.Drawing.Size(46, 20);
            this.tx_tarea4.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label9.Location = new System.Drawing.Point(17, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Quiz#1:";
            // 
            // tx_quiz1
            // 
            this.tx_quiz1.Location = new System.Drawing.Point(62, 24);
            this.tx_quiz1.Name = "tx_quiz1";
            this.tx_quiz1.Size = new System.Drawing.Size(46, 20);
            this.tx_quiz1.TabIndex = 15;
            // 
            // tx_quiz2
            // 
            this.tx_quiz2.Location = new System.Drawing.Point(175, 24);
            this.tx_quiz2.Name = "tx_quiz2";
            this.tx_quiz2.Size = new System.Drawing.Size(46, 20);
            this.tx_quiz2.TabIndex = 16;
            // 
            // tx_quiz3
            // 
            this.tx_quiz3.Location = new System.Drawing.Point(288, 24);
            this.tx_quiz3.Name = "tx_quiz3";
            this.tx_quiz3.Size = new System.Drawing.Size(46, 20);
            this.tx_quiz3.TabIndex = 17;
            // 
            // tx_quiz_total
            // 
            this.tx_quiz_total.Location = new System.Drawing.Point(401, 24);
            this.tx_quiz_total.Name = "tx_quiz_total";
            this.tx_quiz_total.ReadOnly = true;
            this.tx_quiz_total.Size = new System.Drawing.Size(46, 20);
            this.tx_quiz_total.TabIndex = 18;
            this.tx_quiz_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label10.Location = new System.Drawing.Point(125, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Quiz#2:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label11.Location = new System.Drawing.Point(238, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Quiz#3:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label12.Location = new System.Drawing.Point(344, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "Nota Quiz:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label13.Location = new System.Drawing.Point(17, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Tareas:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label14.Location = new System.Drawing.Point(17, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Quizzes:";
            // 
            // tx_porc_quizzes
            // 
            this.tx_porc_quizzes.Location = new System.Drawing.Point(74, 66);
            this.tx_porc_quizzes.Name = "tx_porc_quizzes";
            this.tx_porc_quizzes.Size = new System.Drawing.Size(46, 20);
            this.tx_porc_quizzes.TabIndex = 22;
            // 
            // tx_porc_tareas
            // 
            this.tx_porc_tareas.Location = new System.Drawing.Point(74, 28);
            this.tx_porc_tareas.Name = "tx_porc_tareas";
            this.tx_porc_tareas.Size = new System.Drawing.Size(46, 20);
            this.tx_porc_tareas.TabIndex = 23;
            // 
            // tx_porc_parcial1
            // 
            this.tx_porc_parcial1.Location = new System.Drawing.Point(225, 28);
            this.tx_porc_parcial1.Name = "tx_porc_parcial1";
            this.tx_porc_parcial1.Size = new System.Drawing.Size(46, 20);
            this.tx_porc_parcial1.TabIndex = 24;
            // 
            // tx_porc_parcial2
            // 
            this.tx_porc_parcial2.Location = new System.Drawing.Point(225, 69);
            this.tx_porc_parcial2.Name = "tx_porc_parcial2";
            this.tx_porc_parcial2.Size = new System.Drawing.Size(46, 20);
            this.tx_porc_parcial2.TabIndex = 25;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label15.Location = new System.Drawing.Point(172, 72);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Parcial#2:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label16.Location = new System.Drawing.Point(172, 31);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "Parcial#1:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label17.Location = new System.Drawing.Point(317, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "Parcial#3:";
            // 
            // tx_porc_parcial3
            // 
            this.tx_porc_parcial3.Location = new System.Drawing.Point(378, 24);
            this.tx_porc_parcial3.Name = "tx_porc_parcial3";
            this.tx_porc_parcial3.Size = new System.Drawing.Size(46, 20);
            this.tx_porc_parcial3.TabIndex = 29;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label18.Location = new System.Drawing.Point(128, 31);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 13);
            this.label18.TabIndex = 8;
            this.label18.Text = "%";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label19.Location = new System.Drawing.Point(128, 72);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 13);
            this.label19.TabIndex = 30;
            this.label19.Text = "%";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label20.Location = new System.Drawing.Point(285, 73);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 13);
            this.label20.TabIndex = 31;
            this.label20.Text = "%";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label21.Location = new System.Drawing.Point(285, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(15, 13);
            this.label21.TabIndex = 32;
            this.label21.Text = "%";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label22.Location = new System.Drawing.Point(432, 28);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(15, 13);
            this.label22.TabIndex = 33;
            this.label22.Text = "%";
            // 
            // frm_evaluacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 427);
            this.Controls.Add(this.b_cerrar);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_evaluacion";
            this.Text = "Evaluación";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button b_cerrar;
        private System.Windows.Forms.Button b_nota;
        private System.Windows.Forms.TextBox tx_nota_final;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tx_parcial3;
        private System.Windows.Forms.TextBox tx_parcial2;
        private System.Windows.Forms.TextBox tx_parcial1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tx_tarea2;
        private System.Windows.Forms.TextBox tx_tarea1;
        private System.Windows.Forms.Label tx_4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tx_nota_tareas;
        private System.Windows.Forms.TextBox tx_tarea4;
        private System.Windows.Forms.TextBox tx_tarea3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tx_quiz_total;
        private System.Windows.Forms.TextBox tx_quiz3;
        private System.Windows.Forms.TextBox tx_quiz2;
        private System.Windows.Forms.TextBox tx_quiz1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tx_porc_parcial3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tx_porc_parcial2;
        private System.Windows.Forms.TextBox tx_porc_parcial1;
        private System.Windows.Forms.TextBox tx_porc_tareas;
        private System.Windows.Forms.TextBox tx_porc_quizzes;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
    }
}