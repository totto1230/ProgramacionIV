﻿namespace Tarea1_Joseph_Granados
{
    partial class frm_restaurante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gb_calcular = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.b_cerrar = new System.Windows.Forms.Button();
            this.tx_hamburguesa_cantidad = new System.Windows.Forms.TextBox();
            this.tx_cerveza_cantidad = new System.Windows.Forms.TextBox();
            this.tx_gaseosa_cantidad = new System.Windows.Forms.TextBox();
            this.tx_ensalada_cantidad = new System.Windows.Forms.TextBox();
            this.tx_salchichas_cantidad = new System.Windows.Forms.TextBox();
            this.tx_refresco_cantidad = new System.Windows.Forms.TextBox();
            this.tx_sopa_cantidad = new System.Windows.Forms.TextBox();
            this.tx_postre_cantidad = new System.Windows.Forms.TextBox();
            this.tx_hamburguesa_precio = new System.Windows.Forms.TextBox();
            this.tx_cerveza_precio = new System.Windows.Forms.TextBox();
            this.tx_gaseosa_precio = new System.Windows.Forms.TextBox();
            this.tx_ensalada_precio = new System.Windows.Forms.TextBox();
            this.tx_salchichas_precio = new System.Windows.Forms.TextBox();
            this.tx_refresco_precio = new System.Windows.Forms.TextBox();
            this.tx_sopa_precio = new System.Windows.Forms.TextBox();
            this.tx_postre_precio = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tx_total = new System.Windows.Forms.TextBox();
            this.b_calcular = new System.Windows.Forms.Button();
            this.b_limpiar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.gb_calcular.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tx_total);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.tx_postre_precio);
            this.groupBox1.Controls.Add(this.tx_sopa_precio);
            this.groupBox1.Controls.Add(this.tx_refresco_precio);
            this.groupBox1.Controls.Add(this.tx_salchichas_precio);
            this.groupBox1.Controls.Add(this.tx_ensalada_precio);
            this.groupBox1.Controls.Add(this.tx_gaseosa_precio);
            this.groupBox1.Controls.Add(this.tx_cerveza_precio);
            this.groupBox1.Controls.Add(this.tx_hamburguesa_precio);
            this.groupBox1.Controls.Add(this.tx_postre_cantidad);
            this.groupBox1.Controls.Add(this.tx_sopa_cantidad);
            this.groupBox1.Controls.Add(this.tx_refresco_cantidad);
            this.groupBox1.Controls.Add(this.tx_salchichas_cantidad);
            this.groupBox1.Controls.Add(this.tx_ensalada_cantidad);
            this.groupBox1.Controls.Add(this.tx_gaseosa_cantidad);
            this.groupBox1.Controls.Add(this.tx_cerveza_cantidad);
            this.groupBox1.Controls.Add(this.tx_hamburguesa_cantidad);
            this.groupBox1.Controls.Add(this.gb_calcular);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(527, 363);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ventas";
            // 
            // gb_calcular
            // 
            this.gb_calcular.Controls.Add(this.b_limpiar);
            this.gb_calcular.Controls.Add(this.b_calcular);
            this.gb_calcular.Location = new System.Drawing.Point(306, 84);
            this.gb_calcular.Name = "gb_calcular";
            this.gb_calcular.Size = new System.Drawing.Size(200, 100);
            this.gb_calcular.TabIndex = 10;
            this.gb_calcular.TabStop = false;
            this.gb_calcular.Text = "Opciones";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(221, 35);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Precio";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(125, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Cantidad";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Postre:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 283);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Sopa:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 249);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Refresco:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Salchichas:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ensalada:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Gaseosa:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cerveza:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hamburguesas:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // b_cerrar
            // 
            this.b_cerrar.Location = new System.Drawing.Point(464, 382);
            this.b_cerrar.Name = "b_cerrar";
            this.b_cerrar.Size = new System.Drawing.Size(75, 23);
            this.b_cerrar.TabIndex = 1;
            this.b_cerrar.Text = "Cerrar";
            this.b_cerrar.UseVisualStyleBackColor = true;
            this.b_cerrar.Click += new System.EventHandler(this.b_cerrar_Click);
            // 
            // tx_hamburguesa_cantidad
            // 
            this.tx_hamburguesa_cantidad.Location = new System.Drawing.Point(119, 59);
            this.tx_hamburguesa_cantidad.Name = "tx_hamburguesa_cantidad";
            this.tx_hamburguesa_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_hamburguesa_cantidad.TabIndex = 11;
            // 
            // tx_cerveza_cantidad
            // 
            this.tx_cerveza_cantidad.Location = new System.Drawing.Point(119, 100);
            this.tx_cerveza_cantidad.Name = "tx_cerveza_cantidad";
            this.tx_cerveza_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_cerveza_cantidad.TabIndex = 12;
            // 
            // tx_gaseosa_cantidad
            // 
            this.tx_gaseosa_cantidad.Location = new System.Drawing.Point(119, 134);
            this.tx_gaseosa_cantidad.Name = "tx_gaseosa_cantidad";
            this.tx_gaseosa_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_gaseosa_cantidad.TabIndex = 13;
            // 
            // tx_ensalada_cantidad
            // 
            this.tx_ensalada_cantidad.Location = new System.Drawing.Point(119, 171);
            this.tx_ensalada_cantidad.Name = "tx_ensalada_cantidad";
            this.tx_ensalada_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_ensalada_cantidad.TabIndex = 14;
            // 
            // tx_salchichas_cantidad
            // 
            this.tx_salchichas_cantidad.Location = new System.Drawing.Point(119, 208);
            this.tx_salchichas_cantidad.Name = "tx_salchichas_cantidad";
            this.tx_salchichas_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_salchichas_cantidad.TabIndex = 15;
            // 
            // tx_refresco_cantidad
            // 
            this.tx_refresco_cantidad.Location = new System.Drawing.Point(119, 242);
            this.tx_refresco_cantidad.Name = "tx_refresco_cantidad";
            this.tx_refresco_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_refresco_cantidad.TabIndex = 16;
            // 
            // tx_sopa_cantidad
            // 
            this.tx_sopa_cantidad.Location = new System.Drawing.Point(119, 276);
            this.tx_sopa_cantidad.Name = "tx_sopa_cantidad";
            this.tx_sopa_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_sopa_cantidad.TabIndex = 17;
            // 
            // tx_postre_cantidad
            // 
            this.tx_postre_cantidad.Location = new System.Drawing.Point(119, 306);
            this.tx_postre_cantidad.Name = "tx_postre_cantidad";
            this.tx_postre_cantidad.Size = new System.Drawing.Size(55, 20);
            this.tx_postre_cantidad.TabIndex = 18;
            // 
            // tx_hamburguesa_precio
            // 
            this.tx_hamburguesa_precio.Location = new System.Drawing.Point(212, 59);
            this.tx_hamburguesa_precio.Name = "tx_hamburguesa_precio";
            this.tx_hamburguesa_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_hamburguesa_precio.TabIndex = 19;
            // 
            // tx_cerveza_precio
            // 
            this.tx_cerveza_precio.Location = new System.Drawing.Point(212, 100);
            this.tx_cerveza_precio.Name = "tx_cerveza_precio";
            this.tx_cerveza_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_cerveza_precio.TabIndex = 20;
            // 
            // tx_gaseosa_precio
            // 
            this.tx_gaseosa_precio.Location = new System.Drawing.Point(212, 138);
            this.tx_gaseosa_precio.Name = "tx_gaseosa_precio";
            this.tx_gaseosa_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_gaseosa_precio.TabIndex = 21;
            // 
            // tx_ensalada_precio
            // 
            this.tx_ensalada_precio.Location = new System.Drawing.Point(212, 171);
            this.tx_ensalada_precio.Name = "tx_ensalada_precio";
            this.tx_ensalada_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_ensalada_precio.TabIndex = 22;
            // 
            // tx_salchichas_precio
            // 
            this.tx_salchichas_precio.Location = new System.Drawing.Point(212, 208);
            this.tx_salchichas_precio.Name = "tx_salchichas_precio";
            this.tx_salchichas_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_salchichas_precio.TabIndex = 23;
            // 
            // tx_refresco_precio
            // 
            this.tx_refresco_precio.Location = new System.Drawing.Point(212, 246);
            this.tx_refresco_precio.Name = "tx_refresco_precio";
            this.tx_refresco_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_refresco_precio.TabIndex = 24;
            // 
            // tx_sopa_precio
            // 
            this.tx_sopa_precio.Location = new System.Drawing.Point(212, 276);
            this.tx_sopa_precio.Name = "tx_sopa_precio";
            this.tx_sopa_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_sopa_precio.TabIndex = 25;
            // 
            // tx_postre_precio
            // 
            this.tx_postre_precio.Location = new System.Drawing.Point(212, 306);
            this.tx_postre_precio.Name = "tx_postre_precio";
            this.tx_postre_precio.Size = new System.Drawing.Size(55, 20);
            this.tx_postre_precio.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(116, 338);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Venta Total:";
            // 
            // tx_total
            // 
            this.tx_total.Location = new System.Drawing.Point(187, 335);
            this.tx_total.Name = "tx_total";
            this.tx_total.ReadOnly = true;
            this.tx_total.Size = new System.Drawing.Size(111, 20);
            this.tx_total.TabIndex = 28;
            this.tx_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // b_calcular
            // 
            this.b_calcular.Location = new System.Drawing.Point(56, 23);
            this.b_calcular.Name = "b_calcular";
            this.b_calcular.Size = new System.Drawing.Size(75, 23);
            this.b_calcular.TabIndex = 0;
            this.b_calcular.Text = "Calcular";
            this.b_calcular.UseVisualStyleBackColor = true;
            this.b_calcular.Click += new System.EventHandler(this.b_calcular_Click);
            // 
            // b_limpiar
            // 
            this.b_limpiar.Location = new System.Drawing.Point(56, 57);
            this.b_limpiar.Name = "b_limpiar";
            this.b_limpiar.Size = new System.Drawing.Size(75, 23);
            this.b_limpiar.TabIndex = 1;
            this.b_limpiar.Text = "Limpiar";
            this.b_limpiar.UseVisualStyleBackColor = true;
            this.b_limpiar.Click += new System.EventHandler(this.b_limpiar_Click);
            // 
            // frm_restaurante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 413);
            this.Controls.Add(this.b_cerrar);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_restaurante";
            this.Text = "Restaurante";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gb_calcular.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gb_calcular;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button b_cerrar;
        private System.Windows.Forms.TextBox tx_postre_precio;
        private System.Windows.Forms.TextBox tx_sopa_precio;
        private System.Windows.Forms.TextBox tx_refresco_precio;
        private System.Windows.Forms.TextBox tx_salchichas_precio;
        private System.Windows.Forms.TextBox tx_ensalada_precio;
        private System.Windows.Forms.TextBox tx_gaseosa_precio;
        private System.Windows.Forms.TextBox tx_cerveza_precio;
        private System.Windows.Forms.TextBox tx_hamburguesa_precio;
        private System.Windows.Forms.TextBox tx_postre_cantidad;
        private System.Windows.Forms.TextBox tx_sopa_cantidad;
        private System.Windows.Forms.TextBox tx_refresco_cantidad;
        private System.Windows.Forms.TextBox tx_salchichas_cantidad;
        private System.Windows.Forms.TextBox tx_ensalada_cantidad;
        private System.Windows.Forms.TextBox tx_gaseosa_cantidad;
        private System.Windows.Forms.TextBox tx_cerveza_cantidad;
        private System.Windows.Forms.TextBox tx_hamburguesa_cantidad;
        private System.Windows.Forms.TextBox tx_total;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button b_limpiar;
        private System.Windows.Forms.Button b_calcular;
    }
}